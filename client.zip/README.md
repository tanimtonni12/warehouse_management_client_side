# This is a full stack Project

This project is about Laptop WareHouse Management
[Laptop WareHouse Management]().
[https://laptop-warehouse-managem-a1da6.web.app/](https://laptop-warehouse-managem-a1da6.web.app/).

## About this Project

* In this project in home page there are header, banner, our inventories, our best sellers, delivery and footer .
* In this home page user are able to know about our inventories.
* In header there are login and sign out options also.
* If user is registered then user can login to the system.
* If not register user can register and also can log in by google account.
* If user click on stock update button then if user is login then it will redirect in product detail page otherwise it will take in login page.
* In this project here is also Q&A and blogs pages.
* In this project here user can add items.
* In this project here user can manage and delete items.
* In this project here user can see all inventories and can manage also.
* In this project here user can also see the added inventory that the user add.